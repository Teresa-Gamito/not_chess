src/game/board/board_window.o: src/game/board/board_window.c \
 include/game/board/board_window.h include/ui_elements/window.h \
 include/ui_elements/sprite.h include/helper_functions/typeops.h \
 include/helper_functions/error_handling.h include/ui_elements/button.h \
 include/ui_elements/../inputstate.h \
 include/ui_elements/../helper_functions/helper_functions.h \
 include/ui_elements/textbox.h include/helper_functions/vector.h \
 include/game/board/board.h include/game/board/piece.h \
 include/game/board/tile.h
include/game/board/board_window.h:
include/ui_elements/window.h:
include/ui_elements/sprite.h:
include/helper_functions/typeops.h:
include/helper_functions/error_handling.h:
include/ui_elements/button.h:
include/ui_elements/../inputstate.h:
include/ui_elements/../helper_functions/helper_functions.h:
include/ui_elements/textbox.h:
include/helper_functions/vector.h:
include/game/board/board.h:
include/game/board/piece.h:
include/game/board/tile.h:
