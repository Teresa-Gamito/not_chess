src/game/board/board_setup.o: src/game/board/board_setup.c
