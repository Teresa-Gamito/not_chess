src/ui_elements/object.o: src/ui_elements/object.c \
 src/ui_elements/../../include/ui_elements/object.h \
 src/ui_elements/../../include/ui_elements/../helper_functions/helper_functions.h \
 src/ui_elements/../../include/ui_elements/../helper_functions/error_handling.h
src/ui_elements/../../include/ui_elements/object.h:
src/ui_elements/../../include/ui_elements/../helper_functions/helper_functions.h:
src/ui_elements/../../include/ui_elements/../helper_functions/error_handling.h:
